﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTF2HTML2RTF.Helper
{

    public class Fonttbl
    {
        public string Key { get; set; }
        public string Fnil { get; set; }
        public string Charset { get; set; }
        public string Name { get; set; }
    }
}
