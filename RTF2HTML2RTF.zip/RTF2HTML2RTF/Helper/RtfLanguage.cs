﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTF2HTML2RTF.Helper
{

    internal class RtfLanguage
    {
        Dictionary<string, string> language = new Dictionary<string, string>();

        public Dictionary<string, string> GetLanuages()
        {
            language.Add("lang1033", "Segoe UI");
            language.Add("lang16393", "Segoe UI");

            return language;
        }
    }
}
