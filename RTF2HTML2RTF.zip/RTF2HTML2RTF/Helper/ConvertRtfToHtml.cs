﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Windows.UI;

namespace RTF2HTML2RTF.Helper
{
    public class ConvertRtfToHtml
    {
        #region private Variables
        private const string initTag = "<html> ";
        private const string endTag = " </html>";
        StringBuilder htmlStr;
        private List<Fonttbl> fontTable;
        private List<Colortbl> colorTabel;
        private string numericRegexPattern = "{?(pntext)*.+(f)[0-9].+(u-[0-9][0-9][0-9]).+tab}";
        private string hyperlinkRegexPattern = "{?(cf[0-9])*.+(field){(HYPERLINK)*.+}}}}";
        private string bulletRegexPattern = "{?(pntext)*.+(f)[0-9].+('B7).+tab}";
        string fontRegexPattern = "{\\\\fonttbl.+{\\\\(f[0-9]\\\\(fnil)*.+})";// "{\\\\fonttbl+[^}]+}.+{\\\\(f[0-9]\\\\(fnil)*.+})";
        string colorRegexPattern = "{\\\\colortbl [^}]+}";

        #endregion

        #region Prop
        public List<Fonttbl> FontTable
        {
            get { if (fontTable == null) fontTable = new List<Fonttbl>(); return fontTable; }
            set { fontTable = value; }
        }

        public List<Colortbl> ColorTabel
        {
            get { if (colorTabel == null) colorTabel = new List<Colortbl>(); return colorTabel; }
            set { colorTabel = value; }
        }
        #endregion

        #region Private Mathods         
        private string SetHtmlColorFont(string htmlChar)
        {
            string returnColorFont = htmlChar;
            int cf = 1;
            bool isFC = false;
            foreach (var item in ColorTabel)
            {
                Color myColor = Color.FromArgb(255, Convert.ToByte(item.red), Convert.ToByte(item.green), Convert.ToByte(item.blue));
                string hex = (myColor.R.ToString("X2") + myColor.G.ToString("X2") + myColor.B.ToString("X2")).ToLower();

                if (htmlChar.Contains($"\\{item.key}\\f0"))
                {
                    if (FontTable.Count > 0)
                    {
                        returnColorFont = returnColorFont.Replace($"\\{item.key}\\f0", $"<span style=\"color: {hex}\";> <span style=\"font-family: {FontTable.FirstOrDefault().Name} \";>");
                    }
                    else
                    {
                        returnColorFont = returnColorFont.Replace($"\\{item.key}\\f0", $"<span style=\"color: {hex}\";>");
                    }
                    isFC = true;
                }

                if (cf == 1 && isFC)
                    returnColorFont = returnColorFont.Replace($"\\{item.key}", $"<span style=\"color: {hex} \">");
                else
                    returnColorFont = returnColorFont.Replace($"\\{item.key}", $"</span><span style=\"color: {hex}\">");

                cf++;
                isFC = false;
            }
            if (cf > 1 && returnColorFont.Contains("</p>"))
                returnColorFont = returnColorFont.Insert(returnColorFont.LastIndexOf("</p>"), "</span>");

            // End color close tag replace with span
            if (htmlChar.Contains("\\cf0"))
                returnColorFont = returnColorFont.Replace("\\cf0", "</span>");

            foreach (var item in FontTable)
            {
                if (string.IsNullOrEmpty(item.Charset) && returnColorFont.Contains($"\\{item.Key}"))
                    returnColorFont = returnColorFont.Insert(returnColorFont.IndexOf($"\\{item.Key}"), "</span>").Replace($"\\{item.Key}", string.Empty);
                else if (returnColorFont.Contains($"\\{item.Key}"))
                    returnColorFont = returnColorFont.Insert(returnColorFont.IndexOf($"\\{item.Key}"), $"<span style=\"font-family: {item.Name}\";>").Replace($"\\{item.Key}", string.Empty);
            }

            return returnColorFont;
        }

        private string BoldItalicUnderLineFont(string rtfPard)
        {
            string[] splitChar = { @"\lang" };
            string[] rtfSplit = rtfPard.Split(splitChar, StringSplitOptions.None);

            string rtfTextToChange = rtfPard;
            string htmlChar = RtfIgnore(rtfTextToChange);

            rtfTextToChange = htmlChar;
            //-----------
            htmlChar = ToBold(htmlChar);
            htmlChar = ToItalic(htmlChar);
            htmlChar = ToUnderline(htmlChar);
            htmlChar = ToFontSize(htmlChar);
            //-----------------           

            return htmlChar;
        }

        private string ToFontSize(string rtfPard)
        {
            string fontSizeOpenSyntex = "<font size={0}>";
            string fontSizeCloseSyntex = "</font>";

            string htmlChar = rtfPard;
            MatchCollection matchCeollection = Regex.Matches(htmlChar, "\\\\(fs)(\\d{2,3})");
            bool isFontEndTag = false;
            if (matchCeollection.Count > 0)
            {
                for (int i = 0; i < matchCeollection.Count; i++)
                {
                    bool isFontFound = false;
                    Match fontMatch = Regex.Match(htmlChar, "\\\\(fs)(\\d{2,3})");

                    int fontSize = 0;
                    string sizePettrn = "(\\d{2,3})";
                    Match sizeMatch = Regex.Match(fontMatch.Value, sizePettrn);
                    if (sizeMatch.Success)
                    {
                        int.TryParse(sizeMatch.Value, out fontSize);
                        if (fontSize > 0)
                            fontSize = fontSize / 2;

                        if (htmlChar.Contains(fontMatch.Value))
                        {
                            htmlChar = htmlChar.Remove(htmlChar.IndexOf(fontMatch.Value), fontMatch.Length);

                            htmlChar = htmlChar.Insert(fontMatch.Index, string.Format(fontSizeOpenSyntex, fontSize));
                            isFontFound = true;
                        }

                        // close tag
                        // match end tag
                        int fs = htmlChar.IndexOf("\\fs24\\par\r\n}");
                        if (fs > 0)
                        {
                            htmlChar = htmlChar.Remove(fs, "\\fs24\\par\r\n}".Length);
                            htmlChar = htmlChar.Insert(fs, $"{fontSizeCloseSyntex}</p>");
                            isFontEndTag = true;
                            i++;
                        }
                        int fs2 = htmlChar.IndexOf("\\fs24\\par\r\n");
                        if (fs2 > 0)
                        {
                            htmlChar = htmlChar.Remove(fs2, "\\fs24\\par\r\n".Length);
                            htmlChar = htmlChar.Insert(fs2, $"{fontSizeCloseSyntex}</p><p>");
                            i++;
                        }
                        else if (isFontFound && !isFontEndTag)
                        {
                            int index = htmlChar.IndexOf("\\f1");
                            int index2 = htmlChar.IndexOf("\\par\r\n");
                            int index3 = htmlChar.IndexOf("\\par");

                            //int fs3 = htmlChar.IndexOf("\\fs");

                            //if (fs3 > 0)
                            //    htmlChar = htmlChar.Replace("\\fs", fontSizeCloseSyntex);
                            if (index > 0)
                                htmlChar = htmlChar.Insert(index, fontSizeCloseSyntex);
                            else if (index2 > 0)
                                htmlChar = htmlChar.Insert(index2, fontSizeCloseSyntex);
                            else if (index3 > 0)
                                htmlChar = htmlChar.Insert(index3, fontSizeCloseSyntex);
                        }
                    }


                }
            }

            return htmlChar;
        }

        private string ToBold(string rtfPard)
        {
            string boldHtml = rtfPard;

            string boldEndRegexPattern = "\\\\b0";
            string boldStartRegexPattern = "\\\\b[^0]";

            var totalStartBold = Regex.Matches(boldHtml, boldStartRegexPattern, RegexOptions.Singleline);
            for (int i = 0; i < totalStartBold.Count; i++)
            {
                var startMatch = Regex.Match(boldHtml, boldStartRegexPattern, RegexOptions.Singleline);
                if (startMatch.Success)
                {
                    if (startMatch.Success)
                    {
                        boldHtml = boldHtml.Remove(startMatch.Index, startMatch.Length - 1);
                        boldHtml = boldHtml.Insert(startMatch.Index, "<strong>");
                    }
                }
            }

            var totalEndBold = Regex.Matches(boldHtml, boldEndRegexPattern, RegexOptions.Singleline);
            for (int i = 0; i < totalEndBold.Count; i++)
            {
                var endMatch = Regex.Match(boldHtml, boldEndRegexPattern, RegexOptions.Singleline);
                if (endMatch.Success)
                {
                    if (endMatch.Success)
                    {
                        boldHtml = boldHtml.Remove(endMatch.Index, endMatch.Length);
                        boldHtml = boldHtml.Insert(endMatch.Index, "</strong>");
                    }
                }
            }

            return boldHtml;
        }

        private string ToUnderline(string rtfPard)
        {
            string underHtml = rtfPard;

            string underEndRegexPattern = "\\\\ulnone";
            string underStartRegexPattern = "\\\\ul";

            var totalEndBold = Regex.Matches(underHtml, underEndRegexPattern, RegexOptions.Singleline);
            for (int i = 0; i < totalEndBold.Count; i++)
            {
                var endMatch = Regex.Match(underHtml, underEndRegexPattern, RegexOptions.Singleline);
                if (endMatch.Success)
                {
                    if (endMatch.Success)
                    {
                        underHtml = underHtml.Remove(endMatch.Index, endMatch.Length);
                        underHtml = underHtml.Insert(endMatch.Index, "</u>");
                    }
                }
            }

            var totalStartBold = Regex.Matches(underHtml, underStartRegexPattern, RegexOptions.Singleline);
            for (int i = 0; i < totalStartBold.Count; i++)
            {
                var startMatch = Regex.Match(underHtml, underStartRegexPattern, RegexOptions.Singleline);
                if (startMatch.Success)
                {
                    if (startMatch.Success)
                    {
                        underHtml = underHtml.Remove(startMatch.Index, startMatch.Length);
                        underHtml = underHtml.Insert(startMatch.Index, "<u>");
                    }
                }
            }

            return underHtml;
        }

        private string ToItalic(string rtfPard)
        {
            string italicHtml = rtfPard;

            string italicEndRegexPattern = "\\\\i0";
            string italicStartRegexPattern = "\\\\i[^0]";

            var totalStartBold = Regex.Matches(italicHtml, italicStartRegexPattern, RegexOptions.Singleline);
            for (int i = 0; i < totalStartBold.Count; i++)
            {
                var startMatch = Regex.Match(italicHtml, italicStartRegexPattern, RegexOptions.Singleline);
                if (startMatch.Success)
                {
                    if (startMatch.Success)
                    {
                        italicHtml = italicHtml.Remove(startMatch.Index, startMatch.Length - 1);
                        italicHtml = italicHtml.Insert(startMatch.Index, "<em>");
                    }
                }
            }

            var totalEndBold = Regex.Matches(italicHtml, italicEndRegexPattern, RegexOptions.Singleline);
            for (int i = 0; i < totalEndBold.Count; i++)
            {
                var endMatch = Regex.Match(italicHtml, italicEndRegexPattern, RegexOptions.Singleline);
                if (endMatch.Success)
                {
                    if (endMatch.Success)
                    {
                        italicHtml = italicHtml.Remove(endMatch.Index, endMatch.Length);
                        italicHtml = italicHtml.Insert(endMatch.Index, "</em>");
                    }
                }
            }
            return italicHtml;
        }

        private void GetRtfColorsFontInfo(string rtfHeader)
        {
            // GetFont
            Match fontMatch = Regex.Match(rtfHeader, fontRegexPattern, RegexOptions.IgnorePatternWhitespace);
            if (fontMatch.Success)
            {
                string fonts = fontMatch.Value;

                if (!string.IsNullOrWhiteSpace(fonts))
                {
                    string[] splitChar = { @"{\fonttbl" };
                    string[] fontsValues = fonts.Split(splitChar, StringSplitOptions.RemoveEmptyEntries);
                    if (fontsValues.Length > 0)
                    {
                        string fontValues = fontsValues[0];
                        if (!string.IsNullOrWhiteSpace(fontValues))
                            GetFont(fontValues);
                    }
                }
            }

            // Get Color
            Match colorMatch = Regex.Match(rtfHeader, colorRegexPattern, RegexOptions.IgnorePatternWhitespace);
            if (colorMatch.Success)
            {
                string colors = colorMatch.Value;
                if (!string.IsNullOrWhiteSpace(colors))
                {
                    string[] splitChar = { @"{\colortbl ;" };
                    string[] colorsValues = colors.Split(splitChar, StringSplitOptions.RemoveEmptyEntries);
                    if (colorsValues.Length > 0)
                    {
                        string colorValue = colorsValues[0];
                        if (!string.IsNullOrWhiteSpace(colorValue))
                            GetColor(colorValue);
                    }

                }
            }
            //string[] splitChar = { @"{\fonttbl", @"{\colortbl ;" };
            //string[] fontsColors = rtfHeader.Split(splitChar, StringSplitOptions.RemoveEmptyEntries);

            //string fonts = fontsColors[1];
            //string colors = fontsColors[2].Split('}').FirstOrDefault();
            //if (fontsColors.Length < 3)
            //{
            //    return;
            //}
            //GetFont(fonts);

            //GetColor(colors);
        }

        private void GetFont(string fonts)
        {
            string[] split = fonts.Split('{');
            foreach (var item in split)
            {
                if (!string.IsNullOrWhiteSpace(item))
                {
                    string[] splitFont = item.Split('\\');
                    if (splitFont.Length == 3)
                    {
                        string fCharsetFont = splitFont[2];
                        if (!string.IsNullOrWhiteSpace(fCharsetFont))
                        {
                            var fontname = splitFont[2].Split(' ');

                            if (fontname.Length > 1)
                            {
                                string[] splitForLang = { fontname[0] };
                                var fName = fCharsetFont.Split(splitForLang, StringSplitOptions.RemoveEmptyEntries);
                                if (fName.Length > 0)
                                {
                                    var fontFamily = fName[0].Split(';');
                                    string family = string.Empty;
                                    if (fontFamily.Length > 1)
                                    {
                                        family = fontFamily[0];

                                        FontTable.Add(new Fonttbl { Key = splitFont[1], Fnil = splitForLang[0], Name = family });
                                    }
                                }
                                //var fName = splitFont[2].ToString().Split(splitForLang, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault().Split(';').FirstOrDefault();
                                //FontTable.Add(new Fonttbl { Key = splitFont[1], Fnil = fontname[0], Name = fName });
                            }
                        }
                    }
                    else if (splitFont.Length > 3)
                    {
                        string fCharsetFont = splitFont[3];
                        if (!string.IsNullOrWhiteSpace(fCharsetFont))
                        {
                            var fontname = splitFont[3].Split(' ');
                            if (fontname.Length > 1)
                            {
                                string[] splitForLang = { fontname[0] };
                                var fName = fCharsetFont.Split(splitForLang, StringSplitOptions.RemoveEmptyEntries);
                                if (fName.Length > 0)
                                {
                                    var fontFamily = fName[0].Split(';');
                                    string family = string.Empty;
                                    if (fontFamily.Length > 1)
                                    {
                                        family = fontFamily[0];

                                        FontTable.Add(new Fonttbl { Key = splitFont[1], Fnil = splitFont[2], Charset = fontname[0], Name = family });
                                    }
                                }

                            }
                        }
                    }
                }
            }
        }

        private void GetColor(string colors)
        {
            int cf = 1;
            string[] splitcolor = { @"\red", @"\green", @"\blue" };
            foreach (var item in colors.Split(';'))
            {
                if (string.IsNullOrWhiteSpace(item)) continue;
                string[] colorValue = item.Split(splitcolor, StringSplitOptions.RemoveEmptyEntries);
                if (colorValue.Length == 3)
                {
                    ColorTabel.Add(new Colortbl { key = $"cf{cf}", red = colorValue[0], green = colorValue[1], blue = colorValue[2] });
                    cf++;
                }
            }
        }

        private string ToHtmlRoman(string rtf)
        {
            string[] splitChar = { @"\pard" };
            string[] rtfSplit = rtf.Split(splitChar, StringSplitOptions.RemoveEmptyEntries);

            string htmlChar = string.Empty;
            for (int i = 0; i < rtfSplit.Count(); i++)
            {
                if (i == 0)
                    continue;

                string rtfText = rtfSplit[i];


                if (rtfText.Contains("{\\*\\pn\\pnlvlbody\\pnf0\\pnindent0\\pnstart1\\pnucrm{\\pntxta)}}\r\n\\ltrpar\\tx720\\cf1\\f0\\fs24\\lang1033"))
                    rtfText = rtfText.Replace("{\\*\\pn\\pnlvlbody\\pnf0\\pnindent0\\pnstart1\\pnucrm{\\pntxta)}}\r\n\\ltrpar\\tx720\\cf1\\f0\\fs24\\lang1033", string.Empty);

                MatchCollection matchCollection = Regex.Matches(rtfText, @"tab", RegexOptions.IgnoreCase);
                string rtfRomanFormat1 = @"{\pntext\f0 ";
                string rtfRomanFormat2 = @")\tab}";
                for (int m = 1; m <= matchCollection.Count; m++)
                {
                    string romanKey = RtfTagsData.ToRoman(m);
                    string romanReplaceKey = rtfRomanFormat1 + romanKey + rtfRomanFormat2;
                    if (rtfText.Contains(romanReplaceKey))
                        rtfText = rtfText.Replace(romanReplaceKey, RtfTagsData.RomanTag.HtmlOpenSyntex);
                    else
                        rtfText = rtfText.Insert(0, RtfTagsData.RomanTag.HtmlOpenSyntex);

                    rtfText = rtfText.Replace(@"\f1\lang16393\par", RtfTagsData.RomanTag.HrmlCloseSyntex);
                    rtfText = rtfText.Replace("\\par\r\n", RtfTagsData.RomanTag.HrmlCloseSyntex);
                }

                rtfText = rtfText.Replace("\r\n", string.Empty);
                rtfText = rtfText.Replace("}", string.Empty);
                rtfText = rtfText.Replace("\0", string.Empty);

                htmlChar += rtfText;
            }

            htmlChar = htmlChar.Insert(0, "<ol style='list-style-type:lower-roman;'>");
            htmlChar = htmlChar.Insert(htmlChar.Count(), "</ol>");

            return htmlChar.ToString();
        }

        private string ToHtmlBullet(string rtf, MatchCollection matches)
        {
            string bulletParse = string.Empty;
            var matchUnique = matches.OfType<Match>().Select(x => x.Value).Distinct();
            foreach (string item in matchUnique)
            {
                string[] splitChar = { @"\pard", item };
                string[] rtfSplit = rtf.Split(splitChar, StringSplitOptions.RemoveEmptyEntries);

                for (int i = 0; i < rtfSplit.Count(); i++)
                {
                    string rtfText = rtfSplit[i];
                    if (string.IsNullOrWhiteSpace(rtfText))
                        continue;

                    // First header bullet Comment
                    string bulletCommentRegexPattern = "{(pn?pnlvlblt)*.+('B7)*.+lang[0-9]+";
                    var matchComment = Regex.Match(rtfText, bulletCommentRegexPattern, RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace);
                    if (matchComment.Success)
                    {
                        // Replce also space
                        if (rtfText.Contains($"{matchComment.Value} "))
                            rtfText = rtfText.Replace($"{matchComment.Value} ", RtfTagsData.BulletTag.HtmlOpenSyntex);
                        else
                            rtfText = rtfText.Replace(matchComment.Value, RtfTagsData.BulletTag.HtmlOpenSyntex);
                    }

                    // Second Bullet Comment
                    string bullet2CommentRegexPattern = "{(pn?pnlvlblt)*.+('B7)*.+(ltrpar)?(tx[0-9]+)";
                    var match2Comment = Regex.Match(rtfText, bullet2CommentRegexPattern, RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace);
                    if (match2Comment.Success)
                    {
                        if (rtfText.Contains($"{match2Comment.Value} "))
                            rtfText = rtfText.Replace($"{match2Comment.Value} ", RtfTagsData.BulletTag.HtmlOpenSyntex);
                        else
                            rtfText = rtfText.Replace(match2Comment.Value, RtfTagsData.BulletTag.HtmlOpenSyntex);
                    }

                    string bullet3CommentRegexPattern = "{(pn?pnlvlblt)*.+('B7)*.+(ltrpar)";
                    var match3Comment = Regex.Match(rtfText, bullet3CommentRegexPattern, RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace);
                    if (match3Comment.Success)
                    {
                        if (rtfText.Contains($"{match3Comment.Value} "))
                            rtfText = rtfText.Replace($"{match3Comment.Value} ", RtfTagsData.BulletTag.HtmlOpenSyntex);
                        else
                            rtfText = rtfText.Replace(match3Comment.Value, RtfTagsData.BulletTag.HtmlOpenSyntex);
                    }

                    if (!matchComment.Success && !match2Comment.Success && !match3Comment.Success)
                        rtfText = string.Concat(RtfTagsData.BulletTag.HtmlOpenSyntex, rtfText);

                    string f1LangCommentRegexPattern = "(f[0-9]).+(lang[0-9]+)";
                    var matchf2LangComment = Regex.Match(rtfText, f1LangCommentRegexPattern, RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace);
                    if (matchf2LangComment.Success)
                        rtfText = rtfText.Replace(matchf2LangComment.Value, string.Empty);

                    rtfText = rtfText.Replace("\\par", RtfTagsData.BulletTag.HrmlCloseSyntex);
                    rtfText = rtfText.Replace("\r\n", string.Empty);

                    rtfText = BoldItalicUnderLineFont(rtfText);
                    rtfText = SetHtmlColorFont(rtfText);

                    bulletParse += rtfText;
                }
                // check tags
                //bulletParse = RtfTagsIgnore.FinalIgnoreTag.Aggregate(bulletParse, (c1, c2) => c1.Replace(c2, string.Empty)).TrimEnd();

                bulletParse = string.Concat("<ul>", bulletParse);
                bulletParse = string.Concat(bulletParse, "</ul>");
            }

            return bulletParse;
        }

        private string RtfIgnore(string rtftest)
        {
            string returnText = string.Empty;

            returnText = RtfTagsIgnore.tags.Aggregate(rtftest, (c1, c2) => c1.Replace(c2, string.Empty));

            return returnText;
        }

        private string FixedRtf(string text)
        {
            string returnRtf = text;

            returnRtf = returnRtf.Replace("&", "&amp;");
            returnRtf = returnRtf.Replace("<", "&lt;");
            returnRtf = returnRtf.Replace(">", "&gt;");

            return returnRtf;
        }

        private string ToHyperlink(string rtfPard, MatchCollection matches)
        {
            if (string.IsNullOrWhiteSpace(rtfPard) || matches.Count == 0)
                return rtfPard;

            foreach (Match item in matches)
            {
                var hyperMatch = Regex.Match(item.Value, "http*.+\"");
                if (hyperMatch.Success)
                {
                    string[] fldrsltSplit = { "fldrslt{", "}}}}" };
                    var hyperlinkText = item.Value.Split(fldrsltSplit, StringSplitOptions.RemoveEmptyEntries);
                    var regex = new Regex("{.(field){*.+fldinst{HYPERLINK*.+}}");
                    if (!string.IsNullOrWhiteSpace(hyperlinkText[1]))
                    {
                        Match matchRegex = regex.Match(hyperlinkText[0]);
                        if (matchRegex.Success)
                        {
                            rtfPard = rtfPard.Replace(matchRegex.Value, $"<a href=\"{hyperMatch.Value}>{hyperlinkText[1]}</a></u></span>");
                            var _reg = new Regex("{.fldrslt{*.+}}}}");
                            Match matchReg = _reg.Match(rtfPard);
                            if (matchReg.Success)
                                rtfPard = rtfPard.Replace(matchReg.Value, string.Empty);
                        }
                        else
                        {
                            rtfPard = rtfPard.Replace(item.Value, $"<a href=\"{hyperMatch.Value}>{hyperlinkText[1]}</a></u></span>");
                        }
                    }
                    else
                    {
                        rtfPard = rtfPard.Replace(item.Value, $"<a href=\" \"</a></u></span>");
                    }
                }
                else
                {
                    rtfPard = rtfPard.Replace(item.Value, $"<a href=\" \"</a></u></span>");
                }
            }

            if (rtfPard.Contains("<span>"))
                rtfPard = string.Concat(rtfPard, "</span>");

            return rtfPard;
        }

        private string ToNumeric(string rtfPard, MatchCollection matches)
        {
            if (string.IsNullOrWhiteSpace(rtfPard) || matches.Count == 0)
                return rtfPard;
            foreach (Match match in matches)
            {
                if (rtfPard.Contains("\\par\r\n" + match.Value))
                    rtfPard = rtfPard.Replace(match.Value, "</li><li>");
                else
                    rtfPard = rtfPard.Replace(match.Value, "<li>");
            }

            // remove Comments Tags strings
            string bulletCommentRegexPattern = @"{?(pn).(pnlvlbody)*.+(pnf[0-9])*.+(pnindent[0-9])*.+(pndecd)*.+}}";//{\*\pn\pnlvlbody\pnf[]\pnindent0\pnstart1\pndecd{\pntxta)}}
            var matchComments = Regex.Match(rtfPard, bulletCommentRegexPattern, RegexOptions.IgnoreCase);
            if (matchComments.Success)
            {
                if (rtfPard.Contains($"{matchComments.Value} "))
                    rtfPard = rtfPard.Replace($"{matchComments.Value} ", string.Empty);
                else
                    rtfPard = rtfPard.Replace(matchComments.Value, string.Empty);
            }

            // check tags
            //rtfPard = RtfTagsIgnore.tags.Aggregate(rtfPard, (c1, c2) => c1.Replace(c2, string.Empty)).TrimEnd();
            rtfPard = rtfPard.Replace("{\\*\\", string.Empty);

            rtfPard = BoldItalicUnderLineFont(rtfPard);
            rtfPard = SetHtmlColorFont(rtfPard);

            rtfPard = rtfPard.Replace("\\par", string.Empty);
            rtfPard = rtfPard.Replace("\r\n", string.Empty);

            rtfPard = string.Concat("<ol>", rtfPard);
            rtfPard = string.Concat(rtfPard, "</ol>");

            return rtfPard;
        }

        private string ToParagraph(string rtfPard)
        {
            if (rtfPard.Contains("\\par\r\n}"))
                rtfPard = rtfPard.Replace("\\par\r\n}", "</p>");
            if (rtfPard.Contains("\\par\r\n"))
                rtfPard = rtfPard.Replace("\\par\r\n", "</p><p>");

            return rtfPard;
        }
        #endregion

        #region Public Method
        /// <summary>
        /// Convert Rich text format to html
        /// </summary>
        /// <param name="richText"></param>
        /// <returns></returns>
        public string RtfToHtml(string richText)
        {
#if DEBUG
            Debug.WriteLine("Input RTF:" + richText);
#endif
            if (string.IsNullOrWhiteSpace(richText))
            {
                return string.Empty;
            }

            // Validate isRtftText   
            string pattern = @"{*(rtf)[0-9].+}";
            Match matchRtfText = Regex.Match(richText, pattern, RegexOptions.IgnoreCase);
            if (!matchRtfText.Success)
                return richText;

            htmlStr = new StringBuilder();

            string[] splitPard = { @"\pard" };
            string[] rtfPardSplit = richText.Split(splitPard, StringSplitOptions.None);
            string htmlChar = string.Empty;

            for (int ipard = 0; ipard < rtfPardSplit.Length; ipard++)
            {
                if (ipard == 0)
                {
                    GetRtfColorsFontInfo(rtfPardSplit[0]);
                    continue;
                }
                string toHtmlTemp = string.Empty;
                string rtfPard = rtfPardSplit[ipard];

                // Bullet
                var matchesBullet = Regex.Matches(rtfPard, bulletRegexPattern, RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace);
                if (matchesBullet.Count > 0)
                    rtfPard = ToHtmlBullet(rtfPard, matchesBullet);

                // Roman
                if (rtfPard.Contains(@"{\pntext\f0 I)\tab}") || rtfPard.Contains(@"{\pntext\f1 I)\tab}"))
                    rtfPard = ToHtmlRoman(rtfPard);

                // Numeric
                var matchesNumeric = Regex.Matches(rtfPard, numericRegexPattern, RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace);
                if (matchesNumeric.Count > 0)
                    rtfPard = ToNumeric(rtfPard, matchesNumeric);

                // hyperlink
                var matchHyperlink = Regex.Matches(rtfPard, hyperlinkRegexPattern, RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace);
                if (matchHyperlink.Count > 0)
                    rtfPard = ToHyperlink(rtfPard, matchHyperlink);


                toHtmlTemp = BoldItalicUnderLineFont(rtfPard);
                toHtmlTemp = SetHtmlColorFont(toHtmlTemp);

                htmlChar += string.Concat("<p>", ToParagraph(toHtmlTemp));
            }

            // check tags
            htmlChar = RtfTagsIgnore.FinalIgnoreTag.Aggregate(htmlChar, (c1, c2) => c1.Replace(c2, string.Empty)).TrimEnd();

            htmlStr.Append(initTag);
            htmlStr.Append(htmlChar);
            htmlStr.Append(endTag);


#if DEBUG
            Debug.WriteLine("Output HTML:" + htmlStr.ToString());
#endif

            return htmlStr.ToString();
        }

        #endregion


    }
}
