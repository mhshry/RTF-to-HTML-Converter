﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTF2HTML2RTF.Helper
{
    public class Colortbl
    {
        public string key { get; set; }
        public string red { get; set; }
        public string green { get; set; }
        public string blue { get; set; }
    }
}
