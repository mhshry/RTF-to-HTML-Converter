﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTF2HTML2RTF.Helper
{

    internal class RtfTagsIgnore
    {
        public static List<string> tags = new List<string>
            {
                @"\lang1033", // check regular expression is match use=> lang,
                @"\lang16393",
               // @"\f1",
                @"\ltrpar",@"\tx720",
                //@"\cf1",@"\f0",
               // @"\fs24",
                @"\lang"
            };

        public static List<string> FinalIgnoreTag = new List<string>
            {
                @"{", // check regular expression is match use=> lang,
                @"}",
                @"\r\n",
                "\r\n\0",
                @"0\",
                 @"\par",
                  @"\0",
                 @"\"                
            };

    }
}
