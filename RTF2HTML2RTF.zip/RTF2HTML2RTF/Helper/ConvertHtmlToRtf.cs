﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace RTF2HTML2RTF.Helper
{
    public class ConvertHtmlToRtf
    {
        #region Private Varaibles
        const string endTag = @"\f1\lang16393\par}";
        string initTag = string.Empty;
        const string fontFamilyStart = @"{\f0\fnil\fcharset0 Segoe UI;}";
        string fontFamilyEnd = @"\f{0}\fnil Segoe UI;"; // {0} last Total Count Font-Family
        string fontFamilyMid = @"\f{0}\fnil\fcharset0 {1};";
        const string ColorStart = @"{\colortbl ;\red0\green0\blue0;\red5\green99\blue193;";
        string ColorEnd = "}"; // {0} last Total Count Font-Family
        string ColorMid = @"\red{0}\green{1}\blue{2};";
        #endregion

        #region Constructor
        public ConvertHtmlToRtf()
        {
            initTag = string.Concat(@"{\rtf1\fbidis\ansi\ansicpg1252\deff0\nouicompat\deflang16393", FontFamilyHeader, ColorHeader,
       @"{\*\generator Riched20 10.0.10586}\viewkind4\uc1\pard\ltrpar\tx720\cf1\f0\fs24\lang1033");
        }
        #endregion

        #region Public
        /// <summary>
        /// Convert HTMl to RTF
        /// </summary>
        /// <param name="richText"></param>    
        /// <returns></returns>
        public string HtmlToRtf(string richText)
        {
#if DEBUG
            Debug.WriteLine("Input HTML:" + richText);
#endif
            if (string.IsNullOrWhiteSpace(richText))
            {
                return string.Empty;
            }

            string htmlChar = richText;
            string rtfText = string.Empty;

            string rtfTextToChange = richText;

            foreach (var tags in RtfTagsData.SyntextTagsList.Where(tags => tags.Key != "Font"))
            {
                if (htmlChar.Contains(tags.HtmlOpenSyntex.Trim()))
                {
                    htmlChar = htmlChar.Replace(tags.HtmlOpenSyntex.Trim(), tags.OpenTag);
                }
                if (htmlChar.Contains(tags.HrmlCloseSyntex.Trim()) && !string.IsNullOrWhiteSpace(tags.HrmlCloseSyntex.Trim()))
                {
                    htmlChar = htmlChar.Replace(tags.HrmlCloseSyntex.Trim(), tags.CloseTag);
                }
            }

            foreach (var tags in RtfTagsData.SyntextTagsHtmlToRtfList)
            {
                if (htmlChar.Contains(tags.HtmlOpenSyntex.Trim()))
                {
                    htmlChar = htmlChar.Replace(tags.HtmlOpenSyntex.Trim(), tags.OpenTag);
                }
                if (htmlChar.Contains(tags.HrmlCloseSyntex.Trim()) && !string.IsNullOrWhiteSpace(tags.HrmlCloseSyntex.Trim()))
                {
                    htmlChar = htmlChar.Replace(tags.HrmlCloseSyntex.Trim(), tags.CloseTag);
                }
            }

            htmlChar = ParseNumericList(htmlChar);
            htmlChar = ParseBullets(htmlChar);
            htmlChar = ParseHyperlinks(htmlChar);

            string[] splitHtml = htmlChar.Split('<', '>');
            splitHtml = SetRtfFontFamilyTags(splitHtml);
            splitHtml = SetRtfColorTags(splitHtml);

            // Refresh HeaderTags
            RefreshHeaderTags();

            for (int i = 0; i < splitHtml.Count(); i++)
            {
                string item = splitHtml[i];

                string addHtmlChar = string.Empty;
                if (string.IsNullOrWhiteSpace(item))
                    continue;

                if (item.Contains("span")) // Hack for Background Color
                {
                    if (item.Contains("\\span"))
                        htmlChar.Replace(@"<\span>", @"\par");
                    else if (item.Contains("/span"))
                        htmlChar.Replace(@"<\span>", @"\par");
                    //else
                    //{
                    //    string[] itemChar = { ";" };
                    //    string[] spanSplit = item.Split(itemChar, StringSplitOptions.RemoveEmptyEntries);
                    //    foreach (var itemStyle in spanSplit)
                    //    {
                    //        if (string.IsNullOrWhiteSpace(itemStyle))
                    //            continue;

                    //        string[] itemStyleChar = { ":" };
                    //        string[] styleType = itemStyle.Split(itemStyleChar, StringSplitOptions.RemoveEmptyEntries);
                    //        if (styleType[0].Contains("color"))
                    //            addHtmlChar += "\\cf1";
                    //        else if (styleType[0].Contains("font-family"))
                    //            addHtmlChar += "\\f1";

                    //    }
                    //}
                    splitHtml[i] = string.Empty;
                }

                else if (item.Contains("font size"))
                {
                    Match fontSizeMatch = Regex.Match(item, @"[0-9]+", RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace);
                    if (fontSizeMatch.Success)
                    {
                        int fsize = 1;
                        if (int.TryParse(fontSizeMatch.Value, out fsize))
                            addHtmlChar += $"\\fs{fsize * 2}";
                    }
                    else
                        addHtmlChar += "\\fs24";

                    //htmlChar = htmlChar.Replace($"<{item}>", addHtmlChar);
                    splitHtml[i] = addHtmlChar;
                }
                else if (item.Contains("/font"))
                {
                    splitHtml[i] = "\\fs24";
                }
                else if (item.Contains("html"))
                {
                    splitHtml[i] = string.Empty;
                }
            }

            rtfText = splitHtml.Aggregate((current, next) => current + "" + next);
            rtfText = FixedRtf(rtfText);

            rtfText = string.Concat(initTag, rtfText, endTag);
#if DEBUG
            Debug.WriteLine("Output RTF:" + rtfText);
#endif
            return rtfText;
        }
        #endregion

        #region Private Method
        private void RefreshHeaderTags()
        {
            initTag = string.Concat(@"{\rtf1\fbidis\ansi\ansicpg1252\deff0\nouicompat\deflang16393", FontFamilyHeader, ColorHeader,
       @"{\*\generator Riched20 10.0.10586}\viewkind4\uc1\pard\ltrpar\tx720\cf1\f0\fs24\lang1033");
        }

        private string RtfIgnore(string rtftest)
        {
            string returnText = rtftest.Replace("\\f1", string.Empty);
            returnText = returnText.Replace("1033", string.Empty);

            returnText = FixedRtf(returnText);

            return returnText;
        }

        private string FixedRtf(string text)
        {
            string returnRtf = text;

            returnRtf = returnRtf.Replace("&amp;", "&");
            returnRtf = returnRtf.Replace("&lt;", "<");
            returnRtf = returnRtf.Replace("&gt;", ">");
            returnRtf = returnRtf.Replace("\\r\\n;", string.Empty);
            returnRtf = returnRtf.Replace("<>", string.Empty);

            return returnRtf;
        }

        private static string ParseNumericList(string htmlChar)
        {
            // this passed-in argument may contain string link <ol><li> list Type1 </li></ol> this is in between text <ol><li> another list </li></ol>
            if (string.IsNullOrWhiteSpace(htmlChar) || !htmlChar.Contains(@"<ol>"))
            {
                return htmlChar;
            }

            var listRTFTemplate = @"{\pntext\f0\u-ReplaceCount?)\tab}";
            Regex regex = new Regex("(<ol>\\s+)(.*)(<\\" + Regex.Escape("/") + "ol>)", RegexOptions.Multiline | RegexOptions.Singleline);
            Match match = regex.Match(htmlChar);

            var numericListStr = string.Empty;
            string[] lists = new string[1];

            if (match.Success)
            {
                numericListStr = match.Value;
                lists = numericListStr.Split(new string[] { "</ol>" }, StringSplitOptions.RemoveEmptyEntries);
            }
            else
            {
                numericListStr = htmlChar;
                lists[0] = numericListStr;
            }

            var formattedStr = string.Empty;
            foreach (var numericlist in lists)
            {
                if (numericlist.Contains("<ol>"))
                {
                    formattedStr = numericlist.Replace(@"<ol>", @"\pard {\pntext\f0\u-239?)\tab}{\*\pn\pnlvlbody\pnf0\pnindent0\pnstart1\pndecd{\pntxta)}}\ltrpar\tx720");
                }

                int counter = 239;
                var liTagList = formattedStr.Split(new string[] { "</li>" }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var liTag in liTagList)
                {
                    var liRTFTag = listRTFTemplate.Replace("ReplaceCount", counter.ToString());
                    var formattedRTFliTag = liTag.Replace("<li>", liRTFTag);

                    if (formattedStr.Contains(liTag))
                    {
                        var index = formattedStr.IndexOf(liTag);
                        formattedStr = formattedStr.Remove(index, liTag.Count());
                        formattedStr = formattedStr.Insert(index, formattedRTFliTag);
                    }
                    counter--;
                }
                formattedStr = formattedStr.Replace("</li>", @"\par");
                formattedStr += @"\par\pard";
            }

            if (htmlChar.Contains(numericListStr))
            {
                htmlChar = htmlChar.Replace(numericListStr, formattedStr);
            }
            return htmlChar;
        }

        private static string ParseBullets(string htmlChar)
        {
            if (string.IsNullOrWhiteSpace(htmlChar) || !htmlChar.Contains(@"<ul>"))
            {
                return htmlChar;
            }

            // parse the bullet
            if (htmlChar.Contains("<ul>"))
            {
                htmlChar = htmlChar.Replace(@"<ul>", @"{\*\pn\pnlvlblt\pnf3\pnindent0{\pntxtb\'B7}}");
                htmlChar = htmlChar.Replace(@"<li>", @"{\pntext\f1\'B7\tab}");
                if (htmlChar.Contains(@"</ul>"))
                {
                    htmlChar = htmlChar.Replace(@"</ul>", @"\pard");
                }
                else
                {
                    var lastIndex = htmlChar.LastIndexOf(@"</li>");
                    if (lastIndex > -1)
                        htmlChar = htmlChar.Insert(lastIndex + 5, @"\pard");
                }
                htmlChar = htmlChar.Replace(@"</li>", @"\par");
            }

            return htmlChar;
        }

        private static string ParseHyperlinks(string htmlChar)
        {
            var splitters = htmlChar.Split(new string[] { @"</a>" }, StringSplitOptions.RemoveEmptyEntries);
            Regex regexLink = new Regex("<a*.+>a*.+</a>");
            foreach (var str in splitters)
            {
                var linkStr = string.Empty;
                if (str.Contains("<a href="))
                {
                    var splittersLink = str.Split(new string[] { @"<a href=" }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var s in splittersLink)
                    {
                        if (s.Contains(@"https://") || s.Contains(@"http://"))
                        {
                            linkStr += @"<a href=" + s + "</a>";
                        }
                    }
                }

                Match matchLink = regexLink.Match(linkStr);

                if (matchLink.Success)
                {
                    var value = matchLink.Value;
                    var formattedstr = value.Replace("<a href=", @"\pard\ {\field{\*\fldinst{HYPERLINK ");
                    formattedstr = formattedstr.Replace(@"</a>", @" }}}");
                    formattedstr = formattedstr.Replace(@">", @"}}{\fldrslt{\ul\cf2\ul ");
                    if (!string.IsNullOrWhiteSpace(linkStr))
                        htmlChar = htmlChar.Replace(linkStr, formattedstr);
                }
            }

            return htmlChar;
        }

        private string[] SetRtfFontFamilyTags(string[] html)
        {
            string FontFamily = string.Empty;
            int totalFontFamily = html.Where(x => x.Contains("font-family")).Count();
            int startFontCount = 3;
            for (int i = 0; i < html.Count(); i++)
            {
                string single = html[i];
                if (string.IsNullOrEmpty(single))
                {
                    continue;
                }

                if (single.Contains("font-family"))
                {
                    string[] ffSplit = { "font-family:", "\";" };
                    string[] fontFamily = single.Split(ffSplit, StringSplitOptions.RemoveEmptyEntries);

                    string ffMidid = "{" + string.Format(fontFamilyMid, startFontCount.ToString(), fontFamily[fontFamily.Count() - 1]) + "}";
                    FontFamily += ffMidid;

                    // Set rtf fontFamily
                    html[i] = $"\\f{startFontCount}";

                    // Set Close tag
                    for (int j = i + 1; j < html.Count(); j++)
                    {
                        string close = html[j];
                        if (close.Contains("/span"))
                        {
                            html[j] = "\\f0";
                            break;
                        }
                    }

                    startFontCount++;
                }
            }

            fontFamilyEnd = string.Concat("{", string.Format(fontFamilyEnd, startFontCount.ToString()), "}");

            FontFamilyHeader = string.Concat(@"{\fonttbl", fontFamilyStart, FontFamily, fontFamilyEnd, @"{\f999\fnil\fcharset0 Symbol;}}");
            //FontFamilyHeader = string.Concat(@"{\fonttbl", fontFamilyStart, FontFamily, fontFamilyEnd, "}");

            return html;
        }

        private string[] SetRtfColorTags(string[] html)
        {
            string colorFamily = string.Empty;

            int totalColors = html.Where(x => x.Contains("color:")).Count();
            int startFontCount = 3;
            if (totalColors > 0)
            {
                for (int i = 0; i < html.Count(); i++)
                {
                    string single = html[i];
                    if (string.IsNullOrEmpty(single))
                    {
                        continue;
                    }

                    if (single.Contains("\"color:"))
                    {
                        string[] ffSplit = { "color:", "\";" };
                        string[] colorHex = single.Split(ffSplit, StringSplitOptions.RemoveEmptyEntries);
                        string colorcode = colorHex[colorHex.Count() - 1].Replace("\"", string.Empty);
                        if (!string.IsNullOrEmpty(colorcode))
                        {
                            string ffMidid = string.Empty;
                            uint argb;
                            bool isParseColor = uint.TryParse(colorcode.Replace("#", string.Empty), System.Globalization.NumberStyles.HexNumber,
                                System.Globalization.CultureInfo.InvariantCulture, out argb);

                            if (isParseColor)
                            {
                                Windows.UI.Color clr = ToColor(argb);
                                ffMidid = string.Format(ColorMid, clr.R, clr.G, clr.B);
                            }
                            else
                                ffMidid = string.Format(ColorMid, 0, 0, 0); ;

                            colorFamily += ffMidid;

                            // Set rtf fontFamily
                            html[i] = $@"\cf{startFontCount}";

                            // Set Close tag
                            for (int j = i + 1; j < html.Count(); j++)
                            {
                                string close = html[j];
                                if (close.Contains("/span"))
                                {
                                    html[j] = @"\cf1";
                                    break;
                                }
                            }
                        }

                        startFontCount++;
                    }
                }
            }

            ColorHeader = string.Concat(ColorStart, colorFamily, ColorEnd);

            return html;
        }

        private Windows.UI.Color ToColor(uint argb)
        {
            return Windows.UI.Color.FromArgb((byte)((argb & -16777216) >> 0x18),
                                  (byte)((argb & 0xff0000) >> 0x10),
                                  (byte)((argb & 0xff00) >> 8),
                                  (byte)(argb & 0xff));
        }

        #endregion

        #region Property Font and Color
        private string FontFamilyHeader { get; set; }
        private string ColorHeader { get; set; }//{\colortbl;\red0\green0\blue0;\red5\green99\blue193; } 
        #endregion


    }
}
