﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTF2HTML2RTF.Helper
{
    public static class RtfTagsData
    {
        public static List<Tags> SyntextTagsList = new List<Tags> {
            new Tags { OpenTag="\\b ", CloseTag="\\b0", Key="Bold", HtmlOpenSyntex=" <strong>", HrmlCloseSyntex=" </strong>" },
            new Tags { OpenTag="\\i ", CloseTag="\\i0", Key="Italic", HtmlOpenSyntex=" <em>", HrmlCloseSyntex=" </em>"},
            new Tags { OpenTag="\\ul ", CloseTag="\\ulnone", Key="UnderLine", HtmlOpenSyntex=" <u>", HrmlCloseSyntex=" </u>"},
            new Tags {OpenTag="\\par\r\n", CloseTag="", Key="LineBreak", HtmlOpenSyntex="</p><p>" , HrmlCloseSyntex=""},
            new Tags {OpenTag="\\fs", Key="Font", CloseTag="\\fs", HtmlOpenSyntex="<font size={0}>", HrmlCloseSyntex="</font>" }
        };

        public static List<Tags> SyntextTagsHtmlToRtfList = new List<Tags> {
            new Tags { OpenTag="\\r\\n ", CloseTag="\\r\\n", Key="Par", HtmlOpenSyntex="<p>", HrmlCloseSyntex=" </p>"},
            new Tags { OpenTag="\\par", CloseTag="\\r\\n", Key="Par", HtmlOpenSyntex="<p></p>", HrmlCloseSyntex="</p>"}
        };

        public static Tags BulletTag = new Tags { Key = "Bullet", OpenTag = @"{\pntext\f2\'B7\tab}", CloseTag = @"\f1\lang16393\par", HtmlOpenSyntex = "<li>", HrmlCloseSyntex = "</li>" };

        public static Tags RomanTag = new Tags { Key = "Roman", OpenTag = @"{\pntext\f0 I)\tab}", CloseTag = @"\f1\lang16393\par", HtmlOpenSyntex = "<li>", HrmlCloseSyntex = "</li>" };

        public static string ToRoman(int number)
        {
            if ((number < 0) || (number > 3999)) throw new ArgumentOutOfRangeException("insert value betwheen 1 and 3999");
            if (number < 1) return string.Empty;
            if (number >= 1000) return "M" + ToRoman(number - 1000);
            if (number >= 900) return "CM" + ToRoman(number - 900); //EDIT: i've typed 400 instead 900
            if (number >= 500) return "D" + ToRoman(number - 500);
            if (number >= 400) return "CD" + ToRoman(number - 400);
            if (number >= 100) return "C" + ToRoman(number - 100);
            if (number >= 90) return "XC" + ToRoman(number - 90);
            if (number >= 50) return "L" + ToRoman(number - 50);
            if (number >= 40) return "XL" + ToRoman(number - 40);
            if (number >= 10) return "X" + ToRoman(number - 10);
            if (number >= 9) return "IX" + ToRoman(number - 9);
            if (number >= 5) return "V" + ToRoman(number - 5);
            if (number >= 4) return "IV" + ToRoman(number - 4);
            if (number >= 1) return "I" + ToRoman(number - 1);
            throw new ArgumentOutOfRangeException("something bad happened");
        }

    }
}
