﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTF2HTML2RTF.Helper
{
    public class Tags
    {
        public string Key { get; set; }
        public string OpenTag { get; set; }
        public string CloseTag { get; set; }
        public string HtmlOpenSyntex { get; set; }
        public string HrmlCloseSyntex { get; set; }
    }
}
