﻿using RTF2HTML2RTF.Helper;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Xml;
using Windows.ApplicationModel.DataTransfer;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Popups;
using Windows.UI.Text;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Documents;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Markup;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace RTF2HTML2RTF.UserControl
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class EditorControl : Page
    {
        public EditorControl()
        {
            this.InitializeComponent();
            SetInstalledFonts();
        }

        #region Private Variables

        private string[] fonts;

        #endregion

        #region Dependency Properties


        #endregion

        /// <summary>
        /// Sets installed fonts to Font ComboBox
        /// </summary>
        private void SetInstalledFonts()
        {
            try
            {
                fonts = Microsoft.Graphics.Canvas.Text.CanvasTextFormat.GetSystemFontFamilies();
                List<string> sortedList = new List<string>();
                sortedList.AddRange(fonts);
                sortedList.Sort();
                Font.ItemsSource = sortedList;
                Font.SelectedIndex = 1;
            } // try
            catch (Exception ex)
            {

            } // catch
        } // SetInstalledFonts

        #region Private Methods


        /// <summary>
        ///  Displays the passed-in message in pop-up dialog
        /// </summary>
        private async Task ShowMessage(string message)
        {
            MessageDialog dialog = new MessageDialog(message);
            await dialog.ShowAsync();
        } // ShowMessage

        /// <summary>
        ///  Displays the passed-in exception detals in pop-up dialog
        /// </summary>
        private async Task ShowMessage(Exception ex)
        {
            if (ex.InnerException != null)
            {
                await ShowMessage(ex.InnerException.Message);
            } // if
            else
            {
                await ShowMessage(ex.Message);
            } // else
        } // ShowMessage

        #endregion

        /// <summary>
        ///  Attempts to set the keyboard focus on RichEditBox
        /// </summary>
        private async void Focus()
        {
            try
            {
                Display.Focus(FocusState.Keyboard);
            } // try
            catch (Exception ex)
            {
                await ShowMessage(ex);
            } // catch
        } // Focus

        /// <summary>
        ///  Pastes the clipboard content in rtf format in RichEditBox
        /// </summary>
        private async void Paste_Click(object sender, RoutedEventArgs e)
        {
            // get the content from clipboard
            DataPackageView dataPackageView = Clipboard.GetContent();
            // if data package contains some data in rtf format 
            // then sets that contain next to cursor position
            if (dataPackageView != null
                &&
                dataPackageView.Contains(StandardDataFormats.Rtf))
            {
                try
                {
                    string text = await dataPackageView.GetRtfAsync();
                    Display.Document.Selection.SetText(TextSetOptions.FormatRtf, text);
                }// try
                catch (Exception ex)
                {
                    await ShowMessage(ex);
                }
            } // if
        } // Paste_Click

        /// <summary>
        ///  Copies the selected RichEditBox text to the Clipboard 
        /// </summary>
        private async void Copy_Click(object sender, RoutedEventArgs e)
        {
            if (Display == null
                ||
                Display.Document == null
                ||
                Display.Document.Selection == null
                ||
                Display.Document.Selection.FormattedText == null)
            {
                return;
            }
            try
            {
                // CTODO
                var data = Display.Document.Selection.FormattedText;
                data.Copy();
            } // try
            catch (Exception ex)
            {
                await ShowMessage(ex);
            } // catch
        } // Copy_Click

        /// <summary>
        ///  Cut the selected RichEditBox text to the Clipboard
        /// </summary>
        private async void Cut_Click(object sender, RoutedEventArgs e)
        {

            if (Display == null
                ||
                 Display.Document == null
                ||
                Display.Document.Selection == null
                ||
                Display.Document.Selection.FormattedText == null)
            {
                return;
            }
            try
            {
                var data = Display.Document.Selection.FormattedText;
                data.Cut();
            } // try
            catch (Exception ex)
            {
                await ShowMessage(ex);
            } // catch
        } // Cut_Click

        /// <summary>
        ///  Bold the selected text of RichEditBox 
        /// </summary>
        private async void Bold_Click(object sender, RoutedEventArgs e)
        {
            if (Display == null
                ||
                Display.Document == null
                ||
                Display.Document.Selection == null
                ||
                Display.Document.Selection.CharacterFormat == null)
            {
                return;
            }

            try
            {
                Display.Document.Selection.CharacterFormat.Bold = FormatEffect.Toggle;
                Focus();
                Bold.IsChecked = Display.Document.Selection.CharacterFormat.Bold.Equals(FormatEffect.On);
            } // try
            catch (Exception ex)
            {
                await ShowMessage(ex);
            } // catch
        } // Bold_Click

        /// <summary>
        ///  Italic the selected text of RichEditBox 
        /// </summary>
        private async void Italic_Click(object sender, RoutedEventArgs e)
        {
            if (Display == null
                ||
                Display.Document == null
                ||
                Display.Document.Selection == null
                ||
                Display.Document.Selection.CharacterFormat == null)
            {
                return;
            }

            try
            {
                // CTODO
                Display.Document.Selection.CharacterFormat.Italic = FormatEffect.Toggle;
                Focus();
                Italic.IsChecked = Display.Document.Selection.CharacterFormat.Italic.Equals(FormatEffect.On);
            } // try
            catch (Exception ex)
            {
                await ShowMessage(ex);
            } // catch
        } // Italic_Click

        /// <summary>
        ///  Underline the selected text of RichEditBox 
        /// </summary>
        private async void Underline_Click(object sender, RoutedEventArgs e)
        {
            if (Display == null
                ||
                Display.Document == null
                ||
                Display.Document.Selection == null
                ||
                Display.Document.Selection.CharacterFormat == null)
            {
                return;
            }

            try
            {
                Display.Document.Selection.CharacterFormat.Underline =
                Display.Document.Selection.CharacterFormat.Underline.Equals(UnderlineType.Single) ?
                UnderlineType.None : UnderlineType.Single;
                Focus();
                Underline.IsChecked = Display.Document.Selection.CharacterFormat.Underline.Equals(UnderlineType.Single);
            } // try
            catch (Exception ex)
            {
                await ShowMessage(ex);
            }// catch

        } // Underline_Click

        /// <summary>
        ///  Changes Dont-Family of selected text in RichEditBox
        /// </summary>
        private async void Font_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // if either richEditBox is null or Font comboBox is null then return
            if (Display == null
                ||
                Font == null)
            {
                return;
            } // if Display == null

            // gets the selected item from comboBox
            var selectedFont = Font.SelectedItem as string;
            if (!string.IsNullOrWhiteSpace(selectedFont))
            {
                try
                {
                    string selectedRTFText;
                    Display.Document.Selection.GetText(TextGetOptions.FormatRtf, out selectedRTFText);
                    if (fonts != null)
                    {
                        foreach (var font in fonts)
                        {
                            if (selectedRTFText.Contains(font))
                            {
                                selectedRTFText = selectedRTFText.Replace(font, selectedFont);
                            }
                        }
                    }
                    Display.Document.BeginUndoGroup();
                    Display.Document.Selection.Delete(TextRangeUnit.Story, 1);
                    Display.Document.Selection.SetText(TextSetOptions.FormatRtf, selectedRTFText);
                    Display.Document.EndUndoGroup();
                    // attempts to to set keyboard focus on RichEditBox
                    Focus();
                } // try
                catch (Exception ex)
                {
                    await ShowMessage(ex);
                }// catch
            } // if selectedComboBoxItem != nul
        } // Font_SelectionChanged

        /// <summary>
        /// Changes the selected text color in comboBox as per selected color in ComboBox
        /// </summary>
        private async void Colour_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // if either RichEditBox is null or color comboBox is null then return
            if (Display == null
                ||
                Colour == null)
            {
                return;
            } // if Display == null

            // gets the selected ComboBox item
            var selectedItem = Colour.SelectedItem as ComboBoxItem;

            // if either comboBox selected item is null or Tag value contains null, then return
            if (selectedItem == null
                ||
                selectedItem.Tag == null)
            {
                return;
            } // if (selectedItem == null
            try
            {
                string selectedColor = selectedItem.Tag.ToString();
                uint argb = UInt32.Parse(selectedColor.Replace("#", string.Empty), System.Globalization.NumberStyles.HexNumber);
                Windows.UI.Color clr = ToColor(argb);
                Display.Document.Selection.CharacterFormat.ForegroundColor = clr;
                //Color.FromArgb(
                //    byte.Parse(selectedColor.Substring(0, 2), NumberStyles.HexNumber),
                //    byte.Parse(selectedColor.Substring(2, 2), NumberStyles.HexNumber),
                //    byte.Parse(selectedColor.Substring(4, 2), NumberStyles.HexNumber),
                //    byte.Parse(selectedColor.Substring(6, 2), NumberStyles.HexNumber));
                // attempts to set keyboard focus on RichEditBox
                Colour.SelectedItem = selectedItem;
                Focus();
            }  // try
            catch (Exception ex)
            {
                await ShowMessage(ex);
            } // catch
        } // Colour_SelectiosnChanged

        /// <summary>
        ///  Applies the paragraph bullet on selected text in RichEditBox
        /// </summary>
        private async void Bullets_Click(object sender, RoutedEventArgs e)
        {
            if (Display == null
                ||
                Display.Document == null
                ||
                Display.Document.Selection == null
                ||
                Display.Document.Selection.ParagraphFormat == null)
            {
                return;
            }

            var format = Display.Document.Selection.ParagraphFormat;
            try
            {
                format.ListType = format.ListType == MarkerType.Bullet ?
                                                 MarkerType.None
                                                 : MarkerType.Bullet;
            } // try
            catch (Exception ex)
            {
                await ShowMessage(ex);
            } // catch
        } // Bullets_Click

        /// <summary>
        ///  Applies the paragraph Numbering on selected text in RichEditBox
        /// </summary>
        private async void List_Click(object sender, RoutedEventArgs e)
        {
            if (Display == null
                ||
                Display.Document == null
                ||
                Display.Document.Selection == null
                ||
                Display.Document.Selection.ParagraphFormat == null)
            {
                return;
            }

            var format = Display.Document.Selection.ParagraphFormat;
            try
            {
                format.ListType = format.ListType == MarkerType.ArabicWide ?
                                                     MarkerType.None
                                                     : MarkerType.ArabicWide;
            } // try
            catch (Exception ex)
            {
                await ShowMessage(ex);
            } // catch
        } // List_Click

        /// <summary>
        ///  Fills the Hyperlink pop-up
        /// </summary>
        private void Link_Click(object sender, RoutedEventArgs e)
        {
            if (Display == null
                ||
                Display.Document == null
                ||
                Display.Document.Selection == null)
            {
                return;
            }

            // stores the selected text from the RichEditBox
            string selectedText;
            // gets the selected text from the RichEditBox
            Display.Document.Selection.GetText(TextGetOptions.None, out selectedText);

            // if no text is selected in richEditBox then return
            if (string.IsNullOrWhiteSpace(selectedText))
            {
                return;
            } // if


            // if selected text is already linked with URL then display the URL in Flyout control
            if (!string.IsNullOrWhiteSpace(Display.Document.Selection.Link))
            {
                // gets the URL address from the selection
                var hyperlink = Display.Document.Selection.Link;

                if (!string.IsNullOrWhiteSpace(hyperlink))
                {
                    // sometimes selected text is appended with Hyperlink string
                    // Example::  "HYPERLINK \"http://goggle.com\"Ekta\"
                    var appendingStr = string.Format("HYPERLINK {0}", hyperlink);

                    // remove the encoded string and sets the display text in Flayout control
                    if (Regex.Match(selectedText, appendingStr).Success)
                    {
                        // sets the selected value in textBox
                        this.TextBoxDisplay.Text = selectedText.Replace(appendingStr, "");
                    } // if Regex.Match

                    // remove the "" from the Hyperlink and sets in Flyout control
                    this.TextBoxAddress.Text = hyperlink.Replace("\"", "");
                } // if !string.IsNullOrWhiteSpace(hyperlink
            } // if !string.IsNullOrWhiteSpace

            if (string.IsNullOrWhiteSpace(this.TextBoxDisplay.Text))
            {
                this.TextBoxDisplay.Text = selectedText;
            }
            // sets the focus on TextBox to update the URL address on Pop-up
            Display.Focus(FocusState.Programmatic);
            TextBoxAddress.Focus(FocusState.Keyboard);
        } // Link_Click

        /// <summary>
        ///  Links the Selected text with user specified URL
        /// </summary>
        private void ButtonInsert_Click(object sender, RoutedEventArgs e)
        {
            if (Display == null
                ||
                Display.Document == null)
            {
                return;
            }


            // if no text is selected then return
            if (string.IsNullOrWhiteSpace(TextBoxAddress.Text)
                ||
                 string.IsNullOrWhiteSpace(TextBoxDisplay.Text))
            {
                return;
            } // if string.IsNullOrWhiteSpace(selectedText

            Display.Document.BeginUndoGroup();
            Display.Document.Selection.Delete(TextRangeUnit.Story, 1);
            Display.Document.Selection.SetText(TextSetOptions.None,
                                               TextBoxDisplay.Text.Trim());
            Display.Document.EndUndoGroup();


            // defines the URL sting format
            var url = "\"{0}\"";
            // gets the formatted URL string
            var formattedURL = string.Format(url, TextBoxAddress.Text.Trim());
            // links the URL with selected  text
            Display.Document.Selection.Link = formattedURL;

            // formats the selected text as hyperlink
            if (Display.Document.Selection.CharacterFormat != null)
            {
                Display.Document.Selection.CharacterFormat.Underline = UnderlineType.Single;
                Display.Document.Selection.CharacterFormat.ForegroundColor = Windows.UI.Colors.Blue;
            } // if Display.Document.Selection.CharacterFormat != null

            // applies the changes on RichEditBox
            Display.Document.ApplyDisplayUpdates();
            // Attempts to set focus on RichEditBox
            Display.Focus(FocusState.Keyboard);
            // close hyperlink flyout
            HyperlinkFlyout.Hide();
        } // ButtonInsert_Click

        /// <summary>
        ///  Undo the changes of RichEditBox
        /// </summary>
        private async void Undo_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Display.Document.Undo();
            } // try
            catch (Exception ex)
            {
                await ShowMessage(ex);
            } // catch
        } // Undo_Click

        /// <summary>
        ///  Redo the Previous changes in RichEditBox
        /// </summary>
        private async void Redo_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Display.Document.Redo();
            } // try
            catch (Exception ex)
            {
                await ShowMessage(ex);
            } // catch
        } // Redo_Click

        /// <summary>
        /// Changes the  font size of selected text of RichEditBox
        /// </summary>
        private async void Size_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // if either RichEditBox or ComboBox is null then return 
            if (Display == null
                ||
                Size == null)
            {
                return;
            } // if Display == null

            // gets the selected item of comboBox
            var selectedItem = Size.SelectedItem as ComboBoxItem;

            if (selectedItem != null
                &&
                selectedItem.Tag != null)
            {
                try
                {
                    var fontSize = selectedItem.Tag.ToString();
                    Display.Document.Selection.CharacterFormat.Size = float.Parse(fontSize);
                    Focus();
                } // try
                catch (Exception ex)
                {
                    await ShowMessage(ex);
                }
            } //  if selectedItem != null
            // attempts to set focus n RichEditBox
        } // Size_SelectionChanged

        /// <summary>
        /// Toggles the Buttons as per selected text formatting
        /// </summary>
        private async void Display_SelectionChanged(object sender, RoutedEventArgs e)
        {

            if (Display == null || Display.Document == null || Display.Document.Selection == null)
            {
                return;
            }

            try
            {
                if (Display.Document.Selection.CharacterFormat != null)
                {
                    Bold.IsChecked = Display.Document.Selection.CharacterFormat.Bold.Equals(FormatEffect.On);
                    Italic.IsChecked = Display.Document.Selection.CharacterFormat.Italic.Equals(FormatEffect.On);
                    Underline.IsChecked = Display.Document.Selection.CharacterFormat.Underline.Equals(UnderlineType.Single);
                }


                if (Size != null)
                {
                    var fontWeight = Display.Document.Selection.CharacterFormat.Size;
                    foreach (ComboBoxItem item in Size.Items)
                    {
                        if (item.Tag != null)
                        {
                            try
                            {
                                int fontSize;
                                int.TryParse(item.Tag.ToString(), out fontSize);
                                if (fontWeight == fontSize)
                                {
                                    Size.SelectionChanged -= Size_SelectionChanged;
                                    Size.SelectedItem = item;
                                    Size.SelectionChanged += Size_SelectionChanged;
                                    break;
                                }
                            } // try
                            catch (Exception ex)
                            {
                                await ShowMessage(ex);
                            }
                        } //  if selectedItem != null
                    } // if Size != null

                    if (Display.Document.Selection.ParagraphFormat != null)
                    {
                        var format = Display.Document.Selection.ParagraphFormat;
                        try
                        {
                            Bullets.IsChecked = format.ListType == MarkerType.Bullet;
                            List.IsChecked = format.ListType == MarkerType.ArabicWide;
                        } // try
                        catch (Exception ex)
                        {
                            await ShowMessage(ex);
                        } // catch
                    } // if Display.Document.Selection.ParagraphFormat != null
                }

                if (Font != null)
                {
                    try
                    {
                        string selectedRTFText;
                        Display.Document.Selection.GetText(TextGetOptions.FormatRtf, out selectedRTFText);
                        List<string> selectedTextFonts = new List<string>();
                        foreach (var item in Font.Items)
                        {
                            if (selectedRTFText.Contains(item.ToString()))
                            {
                                selectedTextFonts.Add(item.ToString());
                            }
                        }

                        if (selectedTextFonts.Count > 0)
                        {
                            var index = Font.Items.IndexOf(selectedTextFonts[0]);
                            Font.SelectionChanged -= Font_SelectionChanged;
                            Font.SelectedIndex = index;
                            Font.SelectionChanged += Font_SelectionChanged;
                        }
                    }
                    catch (Exception ex)
                    {
                        await ShowMessage(ex);
                    }
                } // if Font != null


                // if either RichEditBox is null or color comboBox is null then return
                if (Colour != null)
                {
                    try
                    {
                        var selectedTextColor = Display.Document.Selection.CharacterFormat.ForegroundColor;
                        //foreach (var item in Colour.Items)
                        //{
                        //    var comboBoxItem = item as ComboBoxItem;
                        //    if (comboBoxItem.Tag != null)
                        //    {
                        //        var color = comboBoxItem.Tag.ToString();
                        //        uint argb = UInt32.Parse(color.Replace("#", string.Empty), System.Globalization.NumberStyles.HexNumber);
                        //        var RGBColor = ToColor(argb);
                        ////        var RGBColor = Color.FromArgb(
                        ////byte.Parse(color.Substring(0, 2), NumberStyles.HexNumber),
                        ////byte.Parse(color.Substring(2, 2), NumberStyles.HexNumber),
                        ////byte.Parse(color.Substring(4, 2), NumberStyles.HexNumber),
                        ////byte.Parse(color.Substring(6, 2), NumberStyles.HexNumber));

                        //        if (selectedTextColor.ToString() == RGBColor.ToString())
                        //        {
                        //            Colour.SelectionChanged -= Colour_SelectionChanged;
                        //            Colour.SelectedItem = comboBoxItem;
                        //            Colour.SelectionChanged += Colour_SelectionChanged;
                        //        }
                        //    }
                        //}
                    }  // try
                    catch (Exception ex)
                    {
                        await ShowMessage(ex);
                    } // catch
                } //  if Colour = null

                // stores the selected text from the RichEditBox
                string selectedText;
                // gets the selected text from the RichEditBox
                Display.Document.Selection.GetText(TextGetOptions.None, out selectedText);

                if (!string.IsNullOrWhiteSpace(selectedText)
                    &&
                    Regex.Matches(selectedText, "HYPERLINK \"http:").Count + Regex.Matches(selectedText, "HYPERLINK \"https:").Count > 1)
                {
                    Link.IsEnabled = false;
                }
                else
                {
                    Link.IsEnabled = true;
                }
            }
            catch (Exception ex)
            {
                await ShowMessage(ex);
            }
        } // Display_SelectionChanged

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //if (Display.Document != null && Close != null)
            //{
            //    string text;
            //    Display.Document.GetText(TextGetOptions.None, out text);
            //    OperationAttributeValue.Value = text.Trim();

            //    string richText;
            //    Display.Document.GetText(TextGetOptions.FormatRtf, out richText);
            //    OperationAttributeValue.Name = richText;
            //    Close.Execute(null);
            //}
        }

        private void HyperlinkFlyout_Closed(object sender, object e)
        {
            // clear the text before flyout closing
            TextBoxDisplay.Text = string.Empty;
            TextBoxAddress.Text = "http://";
        }

        private void ConvertHtml_Tapped(object sender, TappedRoutedEventArgs e)
        {
            string contentrtf = string.Empty;
            Display.Document.GetText(Windows.UI.Text.TextGetOptions.FormatRtf, out contentrtf);

            string temp;
            // Do not ask for RTF here, we just want the raw text
            Display.Document.GetText(TextGetOptions.None, out temp);
            var range = Display.Document.GetRange(0, temp.Length - 1);

            string text;
            // Ask for RTF here, if desired.
            range.GetText(TextGetOptions.None, out text);
            //RtftoHtmlParser.Instance.ConvertToHtml(contentrtf);

            ConvertRtfToHtml toHtml = new ConvertRtfToHtml();
            string htmlText = toHtml.RtfToHtml(contentrtf);

            TextHtml.Text = htmlText;
            HtmlWebView.NavigateToString(htmlText);
        }
         

        private void ConvertRTF_Tapped(object sender, TappedRoutedEventArgs e)
        {
            //var xaml = HtmlToXamlConverter.ConvertHtmlToXaml(TextHtml.Text, true);
           
            
            ConvertHtmlToRtf toRtf = new ConvertHtmlToRtf();
            string rtfText = toRtf.HtmlToRtf(TextHtml.Text);
            //string rtfText = "{\\rtf1\\ansi\\ansicpg1252\\uc1\\htmautsp\\deff2{\\fonttbl{\\f0\\fcharset0 Times New Roman;}{\\f2\\fcharset0 Segoe UI;}}{\\colortbl\\red0\\green0\\blue0;\\red255\\green255\\blue255;}\r\n{\\*\\listtable\r\n{\\list\\listtemplateid1\\listhybrid\r\n{\\listlevel\\levelnfc23\\levelnfcn23\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid5\\'01\\'b7}{\\levelnumbers;}\\fi-360\\li720\\lin720\\jclisttab\\tx720}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid6\\'02\\'01.;}{\\levelnumbers\\'01;}\\fi-360\\li1440\\lin1440\\jclisttab\\tx1440}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid7\\'02\\'02.;}{\\levelnumbers\\'01;}\\fi-360\\li2160\\lin2160\\jclisttab\\tx2160}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid8\\'02\\'03.;}{\\levelnumbers\\'01;}\\fi-360\\li2880\\lin2880\\jclisttab\\tx2880}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid9\\'02\\'04.;}{\\levelnumbers\\'01;}\\fi-360\\li3600\\lin3600\\jclisttab\\tx3600}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid10\\'02\\'05.;}{\\levelnumbers\\'01;}\\fi-360\\li4320\\lin4320\\jclisttab\\tx4320}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid11\\'02\\'06.;}{\\levelnumbers\\'01;}\\fi-360\\li5040\\lin5040\\jclisttab\\tx5040}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid12\\'02\\'07.;}{\\levelnumbers\\'01;}\\fi-360\\li5760\\lin5760\\jclisttab\\tx5760}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid13\\'02\\'08.;}{\\levelnumbers\\'01;}\\fi-360\\li6480\\lin6480\\jclisttab\\tx6480}\r\n{\\listname ;}\\listid1}\r\n{\\list\\listtemplateid2\\listhybrid\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid14\\'02\\'00.;}{\\levelnumbers\\'01;}\\fi-360\\li720\\lin720\\jclisttab\\tx720}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid15\\'02\\'01.;}{\\levelnumbers\\'01;}\\fi-360\\li1440\\lin1440\\jclisttab\\tx1440}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid16\\'02\\'02.;}{\\levelnumbers\\'01;}\\fi-360\\li2160\\lin2160\\jclisttab\\tx2160}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid17\\'02\\'03.;}{\\levelnumbers\\'01;}\\fi-360\\li2880\\lin2880\\jclisttab\\tx2880}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid18\\'02\\'04.;}{\\levelnumbers\\'01;}\\fi-360\\li3600\\lin3600\\jclisttab\\tx3600}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid19\\'02\\'05.;}{\\levelnumbers\\'01;}\\fi-360\\li4320\\lin4320\\jclisttab\\tx4320}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid20\\'02\\'06.;}{\\levelnumbers\\'01;}\\fi-360\\li5040\\lin5040\\jclisttab\\tx5040}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid21\\'02\\'07.;}{\\levelnumbers\\'01;}\\fi-360\\li5760\\lin5760\\jclisttab\\tx5760}\r\n{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid22\\'02\\'08.;}{\\levelnumbers\\'01;}\\fi-360\\li6480\\lin6480\\jclisttab\\tx6480}\r\n{\\listname ;}\\listid2}}\r\n{\\*\\listoverridetable\r\n{\\listoverride\\listid1\\listoverridecount0\\ls1}\r\n{\\listoverride\\listid2\\listoverridecount0\\ls2}\r\n}\r\n\\loch\\hich\\dbch\\pard\\plain\\ltrpar\\itap0{\\lang1033\\fs18\\f2\\cf0 \\cf0\\ql{\\ql{\\fs24 {\\b\\ltrch mahesh }\\li0\\ri0\\sa0\\sb0\\fi0\\ql\\par}\r\n{\\fs24\\i {\\ltrch arya}\\li0\\ri0\\sa0\\sb0\\fi0\\ql\\par}\r\n{\\fs24 {\\ul\\ltrch hiiiii}\\li0\\ri0\\sa0\\sb0\\fi0\\ql\\par}\r\n{\\fs96 {\\ltrch byee}\\li0\\ri0\\sa0\\sb0\\fi0\\ql\\par}\r\n{\\fs24 {\\ltrch ok}\\li0\\ri0\\sa0\\sb0\\fi0\\ql\\par}\r\n{\\li0\\ri0\\sa0\\sb0\\fi0\\ql\\par}\r\n{\\fs24 {\\pntext \\'B7\\tab}{\\*\\pn\\pnlvlblt\\pnstart1{\\pntxtb\\'B7}}{\\ltrch }{\\ltrch jai}\\li0\\ri0\\sa0\\sb0\\jclisttab\\tx0\\fi-360\\ql\\par}\r\n{\\fs24 {\\pntext \\'B7\\tab}{\\*\\pn\\pnlvlblt\\pnstart1{\\pntxtb\\'B7}}{\\ltrch ho}\\li0\\ri0\\sa0\\sb0\\jclisttab\\tx0\\fi-360\\ql\\par}\r\n{\\fs24 {\\ltrch }\\li0\\ri0\\sa0\\sb0\\fi0\\ql\\par}\r\n{\\fs24 {\\pntext 1.\\tab}{\\*\\pn\\pnlvlbody\\pndec\\pnstart1{\\pntxta .}}{\\ltrch }{\\ltrch finished }\\li0\\ri0\\sa0\\sb0\\jclisttab\\tx0\\fi-360\\ql\\par}\r\n{\\fs24 {\\pntext 2.\\tab}{\\*\\pn\\pnlvlbody\\pndec\\pnstart1{\\pntxta .}}{\\ltrch ho }\\li0\\ri0\\sa0\\sb0\\jclisttab\\tx0\\fi-360\\ql\\par}\r\n{\\fs24 {\\pntext 3.\\tab}{\\*\\pn\\pnlvlbody\\pndec\\pnstart1{\\pntxta .}}{\\ltrch gya}\\li0\\ri0\\sa0\\sb0\\jclisttab\\tx0\\fi-360\\ql\\par}\r\n}\r\n}\r\n}";
            RtfTextBlock.Text = rtfText;
            Display.Document.SetText(TextSetOptions.FormatRtf, rtfText);
            
        }

        private Windows.UI.Color ToColor(uint argb)
        {
            return Windows.UI.Color.FromArgb((byte)((argb & -16777216) >> 0x18),
                                  (byte)((argb & 0xff0000) >> 0x10),
                                  (byte)((argb & 0xff00) >> 8),
                                  (byte)(argb & 0xff));
        }

        private void HtmlText_Changed(object sender, TextChangedEventArgs e)
        {
            HtmlWebView.NavigateToString( (sender as TextBox).Text);
        }
    }
}
